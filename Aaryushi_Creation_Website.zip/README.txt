AARYUSHI CREATION - FREE WEBSITE

Files:
- index.html  : website page
- style.css   : design and responsive layout
- script.js   : mobile menu and year

FREE HOSTING:
1. Upload all three files to any static hosting service such as GitHub Pages, Netlify, or Cloudflare Pages.
2. Keep index.html, style.css and script.js in the same folder.
3. The WhatsApp/call number is currently 9545049093.
4. Edit index.html if you want to add email, address, extra services, or a logo image.

IMPORTANT:
This is a static informational website. It does not process payments or insurance purchases directly.
